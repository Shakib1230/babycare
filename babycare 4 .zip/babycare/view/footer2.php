<div class="footer">

<div class="container">

<p class="copyright">Kazi Babycare @ 2018</p>

</div>

</div>


</body>
