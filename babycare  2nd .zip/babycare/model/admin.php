<?php 
	
	include ('connection.php');

	 class Admin {

	
		public function register_admin($admin_name, $email, $password_1, $gender, $phone, $address){

			$GLOBALS['sql'] = "INSERT INTO admin_details (admin_name, email , password , gender , phone , address ) VALUES('$admin_name','$email' ,'$password_1' , '$gender' ,'$phone','$address');";

			return mysqli_query( $GLOBALS["conn"], $GLOBALS["sql"]);
		}

		public function login_user($email){
			$GLOBALS['sql'] ="SELECT * FROM admin_details WHERE email ='$email'";

			return mysqli_query($GLOBALS["conn"], $GLOBALS["sql"]);
		}


		public function check_email($email){
        	return  mysqli_query($GLOBALS["conn"], "SELECT * FROM admin_details WHERE email ='$email'"); 
		}
	 }	

 ?>