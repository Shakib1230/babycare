<?php 
	
	include ('connection.php');

	 class User {

	
		public function register_child($child_Name, $child_father_name, $child_mother_name, $age, $email, $password_1, $phone, $address, $religion){

			$GLOBALS['sql'] = "INSERT INTO children_details (children_name, children_father_name , children_mother_name , age , email, password, mobile_no, address ,religion ) VALUES('$child_Name','$child_father_name' ,'$child_mother_name' , '$age' ,'$email','$password_1','$phone','$address','$religion');";

			return mysqli_query( $GLOBALS["conn"], $GLOBALS["sql"]);
		}

		public function login_user($email){
			$GLOBALS['sql'] ="SELECT * FROM children_details WHERE email ='$email'";

			return mysqli_query($GLOBALS["conn"], $GLOBALS["sql"]);
		}


		public function check_user_email($email){
        	return  mysqli_query($GLOBALS["conn"], "SELECT * FROM children_details WHERE email ='$email'"); 
		}
	 }	

 ?>