<!DOCTYPE html>
<html>
<head>
	<title>Baby Care</title>
</head>
<body>

	<h1> welcome to Baby Care </h1>

</body>
</html>