
<?php

include '../model/user.php';
include 'connection.php';

$objUser = new User();

session_start();


if (isset($_POST['login_user'])) {

  
  $userEmail = mysqli_real_escape_string($conn, $_POST['userEmail']);
  $password = mysqli_real_escape_string($conn, $_POST['password']);

if (count($errors) == 0) {


    $result = $objUser->login_user($userEmail);
  
    $resultCheck= mysqli_num_rows($result);

    if($resultCheck < 1){

        header("location: ../view/login_user.php?invalid=user/password");

    }



	else {

      if ($row=mysqli_fetch_assoc($result)) {

        $hashedPassCheck = $row['password'];
        if($hashedPassCheck == false){

          header("location: ../view/login_user.php");

        } elseif ($hashedPassCheck == true) {
          //session start
          // $_SESSION['s_id'] = $row['Admin_id'];
          // $_SESSION['s_name'] = $row['Admin_name'];
          // $_SESSION['s_email'] = $row['Admin_email'];

          header("location: ../view/welcome.php");

        }

    }
  }

  }
 else{
  header("location: ../view/login_user.php?");
}
}




?>
