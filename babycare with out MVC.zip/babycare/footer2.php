<div class="footer">

<div class="container">

<p class="copyright">Kazi Baby Care @2018</p>

</div>

</div>


</body>
